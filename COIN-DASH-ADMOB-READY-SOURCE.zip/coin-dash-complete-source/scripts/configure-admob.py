from pathlib import Path
import re
p=Path("android/app/src/main/AndroidManifest.xml")
s=p.read_text()
meta='<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-7674970822891723~3128362140" />'
if 'com.google.android.gms.ads.APPLICATION_ID' not in s:
    s=re.sub(r'(<application\b[^>]*>)', r'\1\n        '+meta, s, count=1)
    p.write_text(s)
