# COIN DASH — Android starter package

This archive contains the playable game source plus a Capacitor Android wrapper configuration and a GitHub Actions workflow.

## Important status
This is **not a compiled APK/AAB and is not published**. The workflow is configured to generate a debug APK artifact after you upload the source to GitHub and run Actions. Google Play requires a properly signed AAB and your Play Console account.

## Quick Android build without Expo
1. Create a GitHub account/repository (or use an existing one).
2. Upload the contents of this archive to the repository's `main` branch.
3. Open **Actions** → **Build Coin Dash Android** → **Run workflow**.
4. When it finishes, download the `coin-dash-debug-apk` artifact.
5. Install the APK on an Android test phone.

The workflow installs Node, Java and Android SDK, creates the Capacitor Android project, and builds a debug APK.

## Google Play and ads
- The source now includes the Capacitor Community AdMob plugin and a native ad bridge. Development is configured with Google official TEST ad unit IDs. The rewarded button grants a life only when the SDK reports a completed reward. Your real ad unit IDs are intentionally not enabled in the test build.
- Before publishing, complete Google/AdMob app review and consent/privacy requirements, then replace the two TEST ad unit IDs in `src/ads.js` with your own approved production ad unit IDs. Keep test IDs during development and never click your own live ads.
- Create a public privacy policy URL, update the template in `PRIVACY-POLICY-TEMPLATE.md`, complete Play Console Data safety / ads / audience declarations truthfully, and add real store graphics.
- Create a signed AAB in Android Studio using your own private upload key. Never share signing keys, passwords, SMS codes or account credentials in chat.

See `RELEASE-CHECKLIST.md` and `PLAY-STORE-LISTING.md`.
