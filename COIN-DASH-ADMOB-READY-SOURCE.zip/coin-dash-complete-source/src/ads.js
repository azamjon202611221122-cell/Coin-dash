import { AdMob } from '@capacitor-community/admob';

// Development uses Google's official TEST ad units. Do not click your own live ads.
const REWARDED_TEST_ID = 'ca-app-pub-3940256099942544/5224354917';
const INTERSTITIAL_TEST_ID = 'ca-app-pub-3940256099942544/1033173712';
let ready = false;
let rewardedLoaded = false;
let interstitialLoaded = false;

async function initialize() {
  if (ready) return;
  try {
    await AdMob.initialize();
    ready = true;
    await loadRewarded();
    await loadInterstitial();
  } catch (error) {
    console.warn('AdMob initialization/load failed; game remains playable.', error);
  }
}
async function loadRewarded() {
  if (!ready) return;
  try {
    await AdMob.prepareRewardVideoAd({ adId: REWARDED_TEST_ID, isTesting: true });
    rewardedLoaded = true;
  } catch (error) { rewardedLoaded = false; console.warn('Rewarded ad unavailable', error); }
}
async function loadInterstitial() {
  if (!ready) return;
  try {
    await AdMob.prepareInterstitial({ adId: INTERSTITIAL_TEST_ID, isTesting: true });
    interstitialLoaded = true;
  } catch (error) { interstitialLoaded = false; console.warn('Interstitial unavailable', error); }
}
window.CoinDashAds = {
  async showRewarded(callback) {
    let earned = false;
    try {
      if (!ready) await initialize();
      if (!rewardedLoaded) await loadRewarded();
      if (!rewardedLoaded) { callback(false); return; }
      const reward = await AdMob.showRewardVideoAd();
      earned = !!reward;
    } catch (error) {
      console.warn('Rewarded ad did not complete', error);
    }
    callback(earned);
    loadRewarded();
  },
  async showInterstitial() {
    try {
      if (!ready) await initialize();
      if (!interstitialLoaded) await loadInterstitial();
      if (interstitialLoaded) await AdMob.showInterstitial();
    } catch (error) { console.warn('Interstitial ad did not show', error); }
    loadInterstitial();
  }
};

// Do not block the game if ads are unavailable or the app is offline.
if (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) {
  initialize();
}
