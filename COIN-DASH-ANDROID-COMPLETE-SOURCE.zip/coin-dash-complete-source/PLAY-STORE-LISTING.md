# Google Play listing draft

**App name:** Coin Dash: Coin Collector  
**Short description:** Collect coins, dodge bombs and beat your best score!  
**Full description:**

Jump into Coin Dash, a quick and colorful arcade challenge. Move left and right, collect shiny coins, avoid dangerous bombs and try to beat your personal best.

FEATURES
- Easy one-finger controls
- Quick arcade rounds
- Local best-score record
- Multiple interface languages
- Optional rewarded-ad continuation (only after a real rewarded ad SDK is connected)

Coin Dash is free to play. No cash prizes or real-money rewards are offered.

**Category suggestion:** Game / Casual  
**Orientation:** Portrait  
**Package ID:** com.coindash.arcade

Before submission, review every statement, add real screenshots and app icon, set the actual support email and privacy policy URL, complete the content rating questionnaire and Data safety form truthfully.
