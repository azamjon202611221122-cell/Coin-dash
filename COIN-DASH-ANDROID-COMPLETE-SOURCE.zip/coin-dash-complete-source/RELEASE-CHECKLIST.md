# Release checklist

## Included now
- HTML5 playable game source
- 10 interface languages (English, Uzbek, Russian, Spanish, French, German, Turkish, Arabic, Hindi, Chinese)
- Local best score
- Coin collection, bomb collision, lives, pause and sound toggle
- Capacitor Android wrapper configuration
- GitHub Actions workflow to produce a **debug APK artifact** after source is pushed to GitHub

## Still required before release
1. Create a GitHub repository, upload this folder, and run Actions. The workflow creates a debug APK; it does not publish the app.
2. Install and test the APK on real Android phones.
3. Integrate a real rewarded-ad SDK and configure your own AdMob app/ad unit IDs. The in-game rewarded continuation is only a bridge placeholder at present; it must not be represented as working until the SDK callback confirms a completed reward.
4. Add consent/privacy handling appropriate to the users' regions and ad SDK.
5. Prepare a final 512x512 icon, feature graphic, phone screenshots, support email and public privacy-policy URL.
6. Complete Google Play Console app setup, content rating, target audience, ads declaration and Data safety form accurately.
7. Generate a signed Android App Bundle (AAB) with a private upload key in Android Studio; keep the key and passwords private.
8. Upload the AAB to an internal testing track, test, then submit for review.

## Build via GitHub Actions
- Create a private or public GitHub repository.
- Upload the contents of this project to the repository's `main` branch.
- Open the repository's **Actions** tab.
- Run **Build Coin Dash Android** (or push to `main`).
- Download the `coin-dash-debug-apk` artifact from the completed workflow.

## Monetization reality
Ad revenue is not guaranteed. It depends on active users, ad impressions, country, ad fill, engagement and policy compliance. Never click your own ads or ask users to click ads. Use test ads during development.
