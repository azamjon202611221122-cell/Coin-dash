// Native Android wrapper should inject this bridge after integrating a rewarded-ad SDK.
// Example contract expected by game.js:
// window.CoinDashAds = { showRewarded: function(callback) { /* show ad; callback(true) only after reward */ } };
// Do not simulate ad completion in production.
