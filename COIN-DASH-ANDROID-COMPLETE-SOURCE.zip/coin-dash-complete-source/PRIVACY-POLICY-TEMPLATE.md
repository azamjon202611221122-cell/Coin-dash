# Coin Dash Privacy Policy — publication template

**Important:** This is a template, not legal advice. Replace every bracketed field and verify it against the final app and SDK configuration before publishing.

Effective date: [DATE]  
Developer: [LEGAL DEVELOPER NAME]  
Contact: [SUPPORT EMAIL]  
Privacy URL: [PUBLIC HTTPS URL]

Coin Dash is a casual arcade game. The current prototype stores the player's best score locally on the device. It does not currently create accounts or send gameplay scores to a developer server.

## Advertising and third-party services
The source project does not yet include a live advertising SDK. If an advertising SDK such as Google Mobile Ads is added, that provider may collect or process device identifiers, IP address, app interaction and diagnostic information for ad delivery, fraud prevention, measurement and consent management. Update this policy and the Google Play Data safety declaration to match the exact SDK version, settings, regions and data practices before release. Link to the advertising provider's current privacy information.

## Children
[Describe the intended age group and whether the app is directed to children. Configure Families policies and child-directed ad treatment if applicable. Do not guess.]

## Data retention and deletion
The prototype's best score remains in local app storage until app data is cleared or the app is uninstalled. [Describe any additional data and deletion process if added.]

## Security
[Describe reasonable security practices relevant to the final app.]

## Changes and contact
We may update this policy when app features or data practices change. Contact [SUPPORT EMAIL] with privacy questions.
